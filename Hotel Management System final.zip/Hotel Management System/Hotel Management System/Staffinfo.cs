﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hotel_Management_System
{
    
    public partial class Staffinfo : Form
    {
        SqlConnection con1=new SqlConnection(@"Data Source=LAPTOP-Geetha\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
        public void details()
        { 
            con1.Open();
            string myq = "select * from Staff_tbl";
            SqlDataAdapter adp = new SqlDataAdapter(myq, con1);
            SqlCommandBuilder cmd = new SqlCommandBuilder(adp);
            var d = new DataSet();
            adp.Fill(d);
            Staffgridview.DataSource = d.Tables[0];
            con1.Close();
        }
        public Staffinfo()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Datelbl1.Text = DateTime.Now.ToLongTimeString();
        }

        private void Staffinfo_Load(object sender, EventArgs e)
        {
            Datelbl1.Text= DateTime.Now.ToLongTimeString();
            timer2.Start();
            details();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MainForm m = new MainForm();
            m.Show();
            this.Hide();
        }

        private void Clientgridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            staffidtbl.Text = Staffgridview.SelectedRows[0].Cells[0].Value.ToString();
            staffnametbl.Text = Staffgridview.SelectedRows[0].Cells[1].Value.ToString();
            staffnumtbl.Text = Staffgridview.SelectedRows[0].Cells[2].Value.ToString();
            staffpasstbl.Text = Staffgridview.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            con1.Open();
            int res=staffpasstbl.Text.Length;
            int start = 3;
            int end = 6;
            SqlCommand cmd = new SqlCommand("insert into Staff_tbl values('" + staffidtbl.Text + "','" + staffnametbl.Text + "','" + staffnumtbl.Text + "','" + staffgentbl.SelectedItem.ToString() + "','" + staffpasstbl.Text + "')", con1);
            if (res > start & res < end)
            {
                
                cmd.ExecuteNonQuery();
                MessageBox.Show("The Staff Details are Successfully Added ");

            }
            else
            {
                MessageBox.Show("Please enter correct format Password should be greater than 3 characters and less than 6 characters");
            }
           
            
            con1.Close();
            details();

        }

        private void Edit_Click(object sender, EventArgs e)
        {
            con1.Open();
            int res = staffpasstbl.Text.Length;
            string query="update Staff_tbl set StaffName='"+staffnametbl.Text+"',StaffPhone='"+staffnumtbl.Text+"',Gender='"+staffgentbl.SelectedItem.ToString()+"',StaffPassword='"+staffpasstbl.Text+"' where StaffId='"+staffidtbl.Text+"'";
            SqlCommand cmd = new SqlCommand(query,con1);
            if (res > 3 & res < 6)
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("The Staff Details are Successfully Updated");
            }
            else 
            {
                MessageBox.Show("Please enter correct format Password should be greater than 3 characters and less than 6 characters"); 
            }
            con1.Close();
            details();

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            con1.Open();
            string query = "delete from Staff_tbl where StaffId='" + staffidtbl.Text + "'";
            SqlCommand cmd= new SqlCommand(query,con1);
            cmd.ExecuteNonQuery();
            MessageBox.Show("The Details Of The Selected Staff Member Is Deleted");
            con1.Close();
            details();

        }

        private void Search_Click(object sender, EventArgs e)
        {
            con1.Open();
            string q = "select * from Staff_tbl where StaffName='"+Staffsearch.Text+"'";
            SqlDataAdapter ad=new SqlDataAdapter(q,con1);
            SqlCommandBuilder cd = new SqlCommandBuilder(ad);
            var d = new DataSet();
            ad.Fill(d);
            Staffgridview.DataSource = d.Tables[0];
            con1.Close();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            details();
        }

        private void Datelbl1_Click(object sender, EventArgs e)
        {

        }

        private void staffpasstbl_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
