﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Hotel_Management_System
{
    public partial class Reservationfrom : Form
    {
        SqlConnection con4=new SqlConnection(@"Data Source=LAPTOP-Geetha\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
        public void details()
        {
            con4.Open();
            string sql = "select * from Reservation_tbl";
            SqlDataAdapter adp = new SqlDataAdapter(sql,con4);
            var d = new DataSet();
            adp.Fill(d);
            Reservationgridview.DataSource = d.Tables[0];
            con4.Close();
        }
        public void fillroomcombo()
        {
            con4.Open();
            SqlCommand cmd = new SqlCommand("select RoomId from Room_tbl where RoomFree='free'", con4);
            SqlDataReader dr =cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RoomId", typeof(int));
            dt.Load(dr);
            resroomidtbl.ValueMember = "RoomId";
            resroomidtbl.DataSource = dt;


            con4.Close();
        }
        public void fillclientcombo()
        {
            con4.Open();
            SqlCommand cmd = new SqlCommand("Select ClientName from Client_tbl", con4);
            SqlDataReader dr =cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("ClientName", typeof(string));
            dt.Load(dr);
            resclientnametbl.ValueMember = "ClientName";
            resclientnametbl.DataSource = dt;
            con4.Close();
        }
        public Reservationfrom()
        {
            InitializeComponent();
        }
       

        private void label2_Click(object sender, EventArgs e)
        {
            MainForm mf=new MainForm();
            mf.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Datelbl4.Text = DateTime.Now.ToLongTimeString();
        }
        DateTime today;

        private void Reservationfrom_Load(object sender, EventArgs e)
        {
            today = datein.Value;
            fillroomcombo();
            fillclientcombo();
            Datelbl4.Text = DateTime.Today.Day.ToString()+"-"+DateTime.Today.Month.ToString()+"-"+DateTime.Today.Year.ToString();
            
            details();

        }

        private void datein_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(datein.Value, today);
            if (res < 0)
                MessageBox.Show("Wrong Date for Reservation");
        }

        private void dateout_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(dateout.Value, datein.Value);
            if (res < 0)
                MessageBox.Show("Choose Valid Out Date");
        }
        public void updateroomstate()
        {
            con4.Open();
            string newstate = "busy";
            string query="update Room_tbl set RoomFree='"+newstate+"' where RoomId='"+Convert.ToInt32(resroomidtbl.SelectedValue.ToString())+"'";
            SqlCommand cmd = new SqlCommand(query, con4);
            cmd.ExecuteNonQuery();

            con4.Close();
            fillroomcombo();

        }
        public void updateroomondelet()
        {
            con4.Open();
            string newstate = "free";
            int inp = Convert.ToInt32(Reservationgridview.SelectedRows[0].Cells[2].Value.ToString());
            string query="update Room_tbl set RoomFree='"+newstate+"' where RoomId='"+inp+"'";
            SqlCommand cmd=new SqlCommand(query, con4);
            cmd.ExecuteNonQuery();
            con4.Close();
            fillroomcombo();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            con4.Open();
            string q = "insert into Reservation_tbl values('"+reservationidtbl.Text+"','"+resclientnametbl.SelectedValue.ToString()+"','"+resroomidtbl.SelectedValue.ToString()+"','"+datein.Value.ToString()+"','"+dateout.Value.ToString()+"')";
            SqlCommand cmd = new SqlCommand(q,con4);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Your Room Reservation is Completed");
            con4.Close();
            updateroomstate();
            details();
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            con4.Open();
            string q = "update Reservation_tbl set Client='"+resclientnametbl.SelectedValue.ToString()+"',Room='"+resroomidtbl.SelectedValue.ToString()+"',DateIn='"+datein.Value.ToString()+"',DateOut='"+dateout.Value.ToString()+"' where ResId='"+reservationidtbl.Text+"'";
            SqlCommand cmd=new SqlCommand(q,con4);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Your Preference of Reservation is Change");
            con4.Close();
            details();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if(reservationidtbl.Text=="")
            {
                MessageBox.Show("enter a Reservation to be Deleted");
            }
            else
            { 
                con4.Open();
                string q = "delete from Reservation_tbl where ResId='" + reservationidtbl.Text + "'";
                SqlCommand c = new SqlCommand(q, con4);
                c.ExecuteNonQuery();
                MessageBox.Show("The Reservation Cancled Successfully");
                con4.Close();
                updateroomondelet();
                details();
            }

        }

        private void roomsearch_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            details();
        }

        private void Search_Click(object sender, EventArgs e)
        {
            con4.Open();
            string q = "select * from Reservation_tbl where ResId='" + roomsearch.Text + "'";
            SqlDataAdapter adp = new SqlDataAdapter(q, con4);
            var d = new DataSet();
            adp.Fill(d);
            Reservationgridview.DataSource = d.Tables[0];

            con4.Close();
        }

        private void Datelbl4_Click(object sender, EventArgs e)
        {

        }

        private void resclientnametbl_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Reservationgridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            reservationidtbl.Text = Reservationgridview.SelectedRows[0].Cells[0].Value.ToString();
        }
    }
}
