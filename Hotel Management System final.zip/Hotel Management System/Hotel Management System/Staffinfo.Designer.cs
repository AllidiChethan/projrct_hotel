﻿namespace Hotel_Management_System
{
    partial class Staffinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Datelbl1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.staffnametbl = new System.Windows.Forms.TextBox();
            this.staffnumtbl = new System.Windows.Forms.TextBox();
            this.staffidtbl = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.staffgentbl = new System.Windows.Forms.ComboBox();
            this.staffpasstbl = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.Staffgridview = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Search = new System.Windows.Forms.Button();
            this.Staffsearch = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Edit = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staffgridview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Linen;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Datelbl1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1303, 150);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1186, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 38);
            this.label2.TabIndex = 3;
            this.label2.Text = "Back";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Datelbl1
            // 
            this.Datelbl1.AutoSize = true;
            this.Datelbl1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datelbl1.Location = new System.Drawing.Point(1014, 94);
            this.Datelbl1.Name = "Datelbl1";
            this.Datelbl1.Size = new System.Drawing.Size(93, 45);
            this.Datelbl1.TabIndex = 2;
            this.Datelbl1.Text = "Date";
            this.Datelbl1.Click += new System.EventHandler(this.Datelbl1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(492, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Staff Information";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(41, 494);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 34);
            this.label6.TabIndex = 15;
            this.label6.Text = "Staff Gender";
            // 
            // staffnametbl
            // 
            this.staffnametbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffnametbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.staffnametbl.Location = new System.Drawing.Point(42, 340);
            this.staffnametbl.Name = "staffnametbl";
            this.staffnametbl.Size = new System.Drawing.Size(269, 26);
            this.staffnametbl.TabIndex = 14;
            this.staffnametbl.Text = "staffname";
            // 
            // staffnumtbl
            // 
            this.staffnumtbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffnumtbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.staffnumtbl.Location = new System.Drawing.Point(42, 444);
            this.staffnumtbl.Name = "staffnumtbl";
            this.staffnumtbl.Size = new System.Drawing.Size(269, 26);
            this.staffnumtbl.TabIndex = 13;
            this.staffnumtbl.Text = "staffnumber";
            // 
            // staffidtbl
            // 
            this.staffidtbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffidtbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.staffidtbl.Location = new System.Drawing.Point(42, 243);
            this.staffidtbl.Name = "staffidtbl";
            this.staffidtbl.Size = new System.Drawing.Size(269, 26);
            this.staffidtbl.TabIndex = 12;
            this.staffidtbl.Text = "staffid";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 384);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 34);
            this.label5.TabIndex = 11;
            this.label5.Text = "Staff Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 34);
            this.label4.TabIndex = 10;
            this.label4.Text = "Staff Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 34);
            this.label3.TabIndex = 9;
            this.label3.Text = "StaffId";
            // 
            // staffgentbl
            // 
            this.staffgentbl.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffgentbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.staffgentbl.FormattingEnabled = true;
            this.staffgentbl.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Not to disclose"});
            this.staffgentbl.Location = new System.Drawing.Point(42, 552);
            this.staffgentbl.Name = "staffgentbl";
            this.staffgentbl.Size = new System.Drawing.Size(269, 24);
            this.staffgentbl.TabIndex = 16;
            this.staffgentbl.Text = "Gender";
            // 
            // staffpasstbl
            // 
            this.staffpasstbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffpasstbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.staffpasstbl.Location = new System.Drawing.Point(42, 648);
            this.staffpasstbl.Name = "staffpasstbl";
            this.staffpasstbl.Size = new System.Drawing.Size(269, 26);
            this.staffpasstbl.TabIndex = 18;
            this.staffpasstbl.Text = "staffpassword";
            this.staffpasstbl.TextChanged += new System.EventHandler(this.staffpasstbl_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 597);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(205, 34);
            this.label7.TabIndex = 17;
            this.label7.Text = "Staff Password";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Staffgridview
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Staffgridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.Staffgridview.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.Staffgridview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Staffgridview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.Staffgridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Staffgridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Staffgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Staffgridview.Location = new System.Drawing.Point(529, 244);
            this.Staffgridview.Name = "Staffgridview";
            this.Staffgridview.RowHeadersWidth = 51;
            this.Staffgridview.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Staffgridview.RowTemplate.Height = 24;
            this.Staffgridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Staffgridview.Size = new System.Drawing.Size(736, 521);
            this.Staffgridview.TabIndex = 19;
            this.Staffgridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Clientgridview_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Hotel_Management_System.Properties.Resources.search2;
            this.pictureBox1.Location = new System.Drawing.Point(1073, 181);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Control;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Search.Location = new System.Drawing.Point(952, 180);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(101, 39);
            this.Search.TabIndex = 22;
            this.Search.Text = "SEARCH";
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // Staffsearch
            // 
            this.Staffsearch.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Staffsearch.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Staffsearch.Location = new System.Drawing.Point(727, 193);
            this.Staffsearch.Name = "Staffsearch";
            this.Staffsearch.Size = new System.Drawing.Size(205, 26);
            this.Staffsearch.TabIndex = 21;
            this.Staffsearch.Text = "staffsearch";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(523, 185);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 34);
            this.label8.TabIndex = 20;
            this.label8.Text = "StaffName";
            // 
            // Edit
            // 
            this.Edit.BackColor = System.Drawing.SystemColors.Control;
            this.Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Edit.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edit.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Edit.Location = new System.Drawing.Point(137, 725);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(84, 39);
            this.Edit.TabIndex = 26;
            this.Edit.Text = "EDIT";
            this.Edit.UseVisualStyleBackColor = false;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.SystemColors.Control;
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Delete.Location = new System.Drawing.Point(238, 725);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(95, 39);
            this.Delete.TabIndex = 25;
            this.Delete.Text = "DELETE";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.SystemColors.Control;
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Add.Location = new System.Drawing.Point(42, 725);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(84, 39);
            this.Add.TabIndex = 24;
            this.Add.Text = "ADD";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Staffinfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1303, 821);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.Staffsearch);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Staffgridview);
            this.Controls.Add(this.staffpasstbl);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.staffgentbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.staffnametbl);
            this.Controls.Add(this.staffnumtbl);
            this.Controls.Add(this.staffidtbl);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Staffinfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Staffinfo";
            this.Load += new System.EventHandler(this.Staffinfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Staffgridview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Datelbl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox staffnametbl;
        private System.Windows.Forms.TextBox staffnumtbl;
        private System.Windows.Forms.TextBox staffidtbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox staffgentbl;
        private System.Windows.Forms.TextBox staffpasstbl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.DataGridView Staffgridview;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.TextBox Staffsearch;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Add;
    }
}