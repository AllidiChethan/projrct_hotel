﻿namespace Hotel_Management_System
{
    partial class Reservationfrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Datelbl4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.reservationidtbl = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.datein = new System.Windows.Forms.DateTimePicker();
            this.dateout = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Search = new System.Windows.Forms.Button();
            this.roomsearch = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Reservationgridview = new System.Windows.Forms.DataGridView();
            this.Edit = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.resroomidtbl = new System.Windows.Forms.ComboBox();
            this.resclientnametbl = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Reservationgridview)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Linen;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Datelbl4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1303, 150);
            this.panel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1186, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 38);
            this.label2.TabIndex = 3;
            this.label2.Text = "Back";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Datelbl4
            // 
            this.Datelbl4.AutoSize = true;
            this.Datelbl4.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datelbl4.Location = new System.Drawing.Point(1014, 94);
            this.Datelbl4.Name = "Datelbl4";
            this.Datelbl4.Size = new System.Drawing.Size(93, 45);
            this.Datelbl4.TabIndex = 2;
            this.Datelbl4.Text = "Date";
            this.Datelbl4.Click += new System.EventHandler(this.Datelbl4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(444, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(414, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reservation Informations";
            // 
            // reservationidtbl
            // 
            this.reservationidtbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reservationidtbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.reservationidtbl.Location = new System.Drawing.Point(65, 237);
            this.reservationidtbl.Name = "reservationidtbl";
            this.reservationidtbl.Size = new System.Drawing.Size(269, 26);
            this.reservationidtbl.TabIndex = 19;
            this.reservationidtbl.Text = "reservationid";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 34);
            this.label3.TabIndex = 18;
            this.label3.Text = "Reservation ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(59, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 34);
            this.label4.TabIndex = 20;
            this.label4.Text = "Client Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(59, 396);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 34);
            this.label5.TabIndex = 22;
            this.label5.Text = "Room Number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(59, 511);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 34);
            this.label6.TabIndex = 24;
            this.label6.Text = "Date IN";
            // 
            // datein
            // 
            this.datein.CalendarForeColor = System.Drawing.SystemColors.HotTrack;
            this.datein.CalendarTitleForeColor = System.Drawing.SystemColors.HotTrack;
            this.datein.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datein.Location = new System.Drawing.Point(65, 573);
            this.datein.Name = "datein";
            this.datein.Size = new System.Drawing.Size(269, 26);
            this.datein.TabIndex = 25;
            this.datein.ValueChanged += new System.EventHandler(this.datein_ValueChanged);
            // 
            // dateout
            // 
            this.dateout.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateout.Location = new System.Drawing.Point(65, 676);
            this.dateout.Name = "dateout";
            this.dateout.Size = new System.Drawing.Size(269, 26);
            this.dateout.TabIndex = 26;
            this.dateout.ValueChanged += new System.EventHandler(this.dateout_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(59, 616);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(136, 34);
            this.label7.TabIndex = 27;
            this.label7.Text = "Date Out";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Hotel_Management_System.Properties.Resources.search2;
            this.pictureBox1.Location = new System.Drawing.Point(1142, 193);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 38);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.SystemColors.Control;
            this.Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Search.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Search.Location = new System.Drawing.Point(1035, 192);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(101, 39);
            this.Search.TabIndex = 38;
            this.Search.Text = "SEARCH";
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // roomsearch
            // 
            this.roomsearch.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomsearch.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.roomsearch.Location = new System.Drawing.Point(824, 206);
            this.roomsearch.Name = "roomsearch";
            this.roomsearch.Size = new System.Drawing.Size(205, 26);
            this.roomsearch.TabIndex = 37;
            this.roomsearch.Text = "roomsearch";
            this.roomsearch.TextChanged += new System.EventHandler(this.roomsearch_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(622, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(196, 34);
            this.label8.TabIndex = 36;
            this.label8.Text = "Room Search";
            // 
            // Reservationgridview
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Reservationgridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.Reservationgridview.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.Reservationgridview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Reservationgridview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.Reservationgridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Reservationgridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.Reservationgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Reservationgridview.Location = new System.Drawing.Point(452, 257);
            this.Reservationgridview.Name = "Reservationgridview";
            this.Reservationgridview.RowHeadersWidth = 51;
            this.Reservationgridview.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.Reservationgridview.RowTemplate.Height = 24;
            this.Reservationgridview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Reservationgridview.Size = new System.Drawing.Size(736, 552);
            this.Reservationgridview.TabIndex = 35;
            this.Reservationgridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Reservationgridview_CellContentClick);
            // 
            // Edit
            // 
            this.Edit.BackColor = System.Drawing.SystemColors.Control;
            this.Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Edit.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Edit.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Edit.Location = new System.Drawing.Point(160, 740);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(84, 39);
            this.Edit.TabIndex = 42;
            this.Edit.Text = "EDIT";
            this.Edit.UseVisualStyleBackColor = false;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.SystemColors.Control;
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Delete.Location = new System.Drawing.Point(261, 740);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(95, 39);
            this.Delete.TabIndex = 41;
            this.Delete.Text = "DELETE";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.SystemColors.Control;
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Add.Location = new System.Drawing.Point(65, 740);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(84, 39);
            this.Add.TabIndex = 40;
            this.Add.Text = "ADD";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "free",
            "busy"});
            this.comboBox1.Location = new System.Drawing.Point(452, 208);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(164, 27);
            this.comboBox1.TabIndex = 43;
            this.comboBox1.Text = "Rooms";
            // 
            // resroomidtbl
            // 
            this.resroomidtbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.resroomidtbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.resroomidtbl.FormattingEnabled = true;
            this.resroomidtbl.Location = new System.Drawing.Point(65, 459);
            this.resroomidtbl.Name = "resroomidtbl";
            this.resroomidtbl.Size = new System.Drawing.Size(269, 26);
            this.resroomidtbl.TabIndex = 44;
            this.resroomidtbl.Text = "roomid";
            this.resroomidtbl.SelectedIndexChanged += new System.EventHandler(this.resclientnametbl_SelectedIndexChanged);
            // 
            // resclientnametbl
            // 
            this.resclientnametbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.resclientnametbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.resclientnametbl.FormattingEnabled = true;
            this.resclientnametbl.Location = new System.Drawing.Point(65, 348);
            this.resclientnametbl.Name = "resclientnametbl";
            this.resclientnametbl.Size = new System.Drawing.Size(269, 26);
            this.resclientnametbl.TabIndex = 45;
            this.resclientnametbl.Text = "clientname";
            // 
            // Reservationfrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1303, 821);
            this.Controls.Add(this.resclientnametbl);
            this.Controls.Add(this.resroomidtbl);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.roomsearch);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Reservationgridview);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateout);
            this.Controls.Add(this.datein);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.reservationidtbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Reservationfrom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reservationfrom";
            this.Load += new System.EventHandler(this.Reservationfrom_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Reservationgridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Datelbl4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox reservationidtbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker datein;
        private System.Windows.Forms.DateTimePicker dateout;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.TextBox roomsearch;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView Reservationgridview;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox resroomidtbl;
        private System.Windows.Forms.ComboBox resclientnametbl;
    }
}