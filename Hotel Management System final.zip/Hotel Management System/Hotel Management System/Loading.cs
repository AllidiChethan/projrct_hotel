﻿using System;
using System.Windows.Forms;

namespace Hotel_Management_System
{
    public partial class Loading : Form
    {
        public Loading()
        {
            InitializeComponent();
        }
        int startpoint = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            startpoint += 1;
            SplashBar.Value = startpoint;
            if (SplashBar.Value == 60)
            {
                SplashBar.Value = 0;
                timer1.Stop();
                Form1 f = new Form1();
                f.Show();
                this.Hide();
            }

        }

        private void Loading_Load(object sender, EventArgs e)
        {
            this.timer1.Start();
        }
    }
}
