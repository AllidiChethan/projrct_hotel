﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hotel_Management_System
{
    public partial class Roomsinfo : Form
    {
        SqlConnection con2 = new SqlConnection(@"Data Source=LAPTOP-Geetha\SQLEXPRESS;Initial Catalog=hotel;Integrated Security=True");
        public void details()
        {
            con2.Open();
            string query = "select * from Room_tbl";
            SqlDataAdapter adp=new SqlDataAdapter(query, con2);
            SqlCommandBuilder cd = new SqlCommandBuilder(adp);
            var d = new DataSet();
            adp.Fill(d);
            Roomgridview.DataSource = d.Tables[0];
            con2.Close();

        }
        public Roomsinfo()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Datelbl3.Text = DateTime.Now.ToLongTimeString();
        }

        private void Datelbl_Click(object sender, EventArgs e)
        {

        }

        private void Roomsinfo_Load(object sender, EventArgs e)
        {
            Datelbl3.Text = DateTime.Now.ToLongTimeString();
            timer3.Start();
            details();
        }

        private void Search_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            string isfree;
            if (yesradio.Checked == true)
            {
                isfree = "free";
            }
            else 
            {
                isfree = "busy";
            }
            con2.Open();
            SqlCommand cmd = new SqlCommand("insert into Room_tbl values('"+roomnotbl.Text+"','"+roomphonetbl.Text+"','"+isfree+"')",con2);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Room successfully Added");
            con2.Close();
            details();
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            con2.Open();
            string isfree;
            if (yesradio.Checked == true)
            {
                isfree = "free";
            }
            else
            {
                isfree = "busy";
            }
            string query = "update Room_tbl set RoomPhone='"+roomphonetbl.Text+"',RoomFree='"+isfree+"' where RoomId='"+roomnotbl.Text+"' ";
            SqlCommand cmd = new SqlCommand(query,con2);
            cmd.ExecuteNonQuery();
            MessageBox.Show("The Room Details are Updated");
            con2.Close();
            details();
        }

        private void Roomgridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            roomnotbl.Text = Roomgridview.SelectedRows[0].Cells[0].Value.ToString();
            roomphonetbl.Text = Roomgridview.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            con2.Open();
            string query = "delete from Room_tbl where RoomId='" + roomnotbl.Text + "'";
            SqlCommand cmd=new SqlCommand(query,con2);
            cmd.ExecuteNonQuery();
            MessageBox.Show("The Room Details are Deleted");
            con2.Close();
            details();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MainForm mf=new MainForm();
            mf.Show();
            this.Hide();
        }

        private void Search_Click_1(object sender, EventArgs e)
        {
            con2.Open();
            string query = "select * from Room_tbl where RoomId='"+roomsearch.Text+"'";
            SqlDataAdapter adp = new SqlDataAdapter(query,con2);
            SqlCommandBuilder cd = new SqlCommandBuilder(adp);
            var d = new DataSet();
            adp.Fill(d);
            Roomgridview.DataSource = d.Tables[0];

            con2.Close();

        }

        private void Staffsearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            details();
        }
    }
}
